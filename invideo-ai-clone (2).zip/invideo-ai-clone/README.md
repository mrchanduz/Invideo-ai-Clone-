# InVideo AI Clone
A simple React-based starter template for deploying to Vercel.