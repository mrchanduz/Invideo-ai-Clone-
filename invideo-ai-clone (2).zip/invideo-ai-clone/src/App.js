import React from "react";

function App() {
  return (
    <div style={{ textAlign: "center", marginTop: "20%" }}>
      <h1>Welcome to InVideo AI Clone</h1>
      <p>This is your AI-powered video editor homepage.</p>
    </div>
  );
}

export default App;